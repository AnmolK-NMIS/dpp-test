"""
Calculator package __init__

Imports basic arithmetic functions from operator.
"""

from .operator import add, subtract, multiply, divide
